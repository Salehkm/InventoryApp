package com.example.saleh.project8.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.saleh.project8.data.contract.Entry;
/**
 * Created by saleh on 14/06/18.
 */

public class dbhelper extends SQLiteOpenHelper {
        private static final String Database_name= "order.db";
        private static final int Database_version = 1;

        public dbhelper(Context context) {
            super(context, Database_name, null, Database_version);
        }
        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            String SQL_CREATE_ORDERS_TABLE =  "CREATE TABLE " + Entry.table_name + " ("
                    + Entry._id + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + Entry.product_name + " TEXT NOT NULL, "
                    + Entry.price + " INTEGER NOT NULL, "
                    + Entry.quantity + " INTEGER NOT NULL,"
                    + Entry.supplier_phone_number +" INTEGER,"
                    + Entry.supplier_name + " TEXT NOT NULL );";
            sqLiteDatabase.execSQL(SQL_CREATE_ORDERS_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        }
    }


