package com.example.saleh.project8.data;

import android.provider.BaseColumns;

/**
 * Created by saleh on 14/06/18.
 */

public final class contract {
    private contract(){}
    public static final class Entry implements BaseColumns{
        public final static String table_name = "orders";
        public final static String _id = BaseColumns._ID;
        public final static String product_name ="product";
        public final static String price = "price";
        public final static String quantity = "quantity";
        public final static String supplier_name= "supplier";
        public final static String supplier_phone_number = "phone";
    }



}
